import { Router, type IRouter } from "express";
import auroraAiRouter from "./aurora-ai";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(auroraAiRouter);

export default router;
