import { Router, type IRouter, type Request } from "express";
import {
  SendAuroraAiMessageBody,
  SendAuroraAiMessageResponse,
} from "@workspace/api-zod";

const GROQ_CHAT_COMPLETIONS_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "openai/gpt-oss-20b";
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_REQUESTS = 8;
const RATE_LIMIT_MAX_CLIENTS = 5_000;
const rateLimitEntries = new Map<string, { count: number; resetAt: number }>();

function pruneRateLimitEntries(now: number): void {
  if (rateLimitEntries.size < RATE_LIMIT_MAX_CLIENTS) return;

  for (const [clientIp, entry] of rateLimitEntries) {
    if (entry.resetAt <= now) rateLimitEntries.delete(clientIp);
  }

  if (rateLimitEntries.size >= RATE_LIMIT_MAX_CLIENTS) {
    const oldestClient = rateLimitEntries.keys().next().value;
    if (oldestClient !== undefined) rateLimitEntries.delete(oldestClient);
  }
}

function isRateLimited(req: Request): boolean {
  const forwardedIp = req.header("x-forwarded-for")?.split(",")[0]?.trim();
  const clientIp = forwardedIp || req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const current = rateLimitEntries.get(clientIp);

  if (!current || current.resetAt <= now) {
    if (current) rateLimitEntries.delete(clientIp);
    else pruneRateLimitEntries(now);
    rateLimitEntries.set(clientIp, { count: 1, resetAt: now + RATE_LIMIT_WINDOW_MS });
    return false;
  }

  if (current.count >= RATE_LIMIT_REQUESTS) return true;
  current.count += 1;
  return false;
}

const router: IRouter = Router();

router.post("/aurora-ai/chat", async (req, res): Promise<void> => {
  const parsed = SendAuroraAiMessageBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ issueCount: parsed.error.issues.length }, "Rejected invalid Aurora AI chat request");
    res.status(400).json({ error: "Send a valid message with no more than 12 recent messages." });
    return;
  }

  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "Aurora AI is not configured yet." });
    return;
  }

  if (isRateLimited(req)) {
    res.status(429).json({ error: "Please wait a minute before sending more messages." });
    return;
  }

  const messages = [
    {
      role: "system",
      content: "You are Aurora AI, a clear, thoughtful, and helpful assistant. Answer directly, be honest about uncertainty, and keep responses easy to read.",
    },
    ...parsed.data.messages.map(({ role, content }) => ({ role, content })),
  ];

  try {
    const upstreamResponse = await fetch(GROQ_CHAT_COMPLETIONS_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages,
        max_completion_tokens: 1200,
      }),
      signal: AbortSignal.timeout(45_000),
    });

    if (upstreamResponse.status === 429) {
      res.status(429).json({ error: "Groq is busy or has reached its rate limit. Try again shortly." });
      return;
    }

    if (!upstreamResponse.ok) {
      req.log.error({ upstreamStatus: upstreamResponse.status }, "Groq chat request failed");
      const error = upstreamResponse.status === 401 || upstreamResponse.status === 403
        ? "Groq rejected the configured API key. Check the GROQ_API_KEY secret."
        : "Groq could not complete the request. Try again shortly.";
      res.status(502).json({ error });
      return;
    }

    const payload = await upstreamResponse.json() as {
      choices?: Array<{ message?: { content?: unknown } }>;
    };
    const reply = payload.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      req.log.error({ upstreamStatus: upstreamResponse.status }, "Groq returned an empty chat response");
      res.status(502).json({ error: "Aurora AI received an empty response. Please try again." });
      return;
    }

    res.json(SendAuroraAiMessageResponse.parse({ reply: reply.trim(), model: GROQ_MODEL }));
  } catch (error) {
    const errorName = error instanceof Error ? error.name : "";
    if (errorName === "TimeoutError" || errorName === "AbortError") {
      res.status(504).json({ error: "Aurora AI took too long to respond. Please try again." });
      return;
    }

    req.log.error({ err: error }, "Aurora AI could not reach Groq");
    res.status(502).json({ error: "Aurora AI could not reach Groq. Please try again shortly." });
  }
});

export default router;