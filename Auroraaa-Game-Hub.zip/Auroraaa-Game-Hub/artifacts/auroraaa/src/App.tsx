import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Link, Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { Check, Compass, ExternalLink, EyeOff, Gamepad2, Globe2, Settings2, ShieldCheck, Sparkles } from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import AuroraAiPage from '@/pages/aurora-ai';
import NotFound from '@/pages/not-found';

type Wallpaper = { kind: 'preset' | 'solid' | 'gradient' | 'url' | 'upload'; value: string; dim: number };
const STORAGE_KEY = 'auroraaa-wallpaper-v1';
const DEFAULT_WALLPAPER: Wallpaper = { kind: 'preset', value: 'aurora', dim: 24 };
const presets = [
  { id: 'aurora', label: 'Aurora veil', css: 'radial-gradient(ellipse at 48% 8%, #165443 0%, #1b3940 24%, #141d31 52%, #0c1020 88%)' },
  { id: 'polar', label: 'Polar night', css: 'radial-gradient(ellipse at 76% 14%, #435b70 0%, #243747 23%, #192433 48%, #0d1321 84%)' },
  { id: 'violet', label: 'Violet hour', css: 'radial-gradient(ellipse at 32% 10%, #554460 0%, #342c4a 27%, #1d2038 55%, #101323 88%)' },
  { id: 'glacier', label: 'Blue glacier', css: 'radial-gradient(ellipse at 56% 8%, #2c6671 0%, #244653 24%, #172d40 52%, #0d1422 86%)' },
  { id: 'dusk', label: 'Last light', css: 'radial-gradient(ellipse at 74% 18%, #755747 0%, #47394a 24%, #27283d 54%, #111522 89%)' },
];
const navigation = [
  { href: '/', label: 'Home', icon: Compass },
  { href: '/games', label: 'Games', icon: Gamepad2 },
  { href: '/apps', label: 'Apps', icon: Globe2 },
  { href: '/aurora-ai', label: 'Aurora AI', icon: Sparkles },
];
const blankRoutes = ['/games', '/apps', '/settings'];
const queryClient = new QueryClient();
const CLOAK_STORAGE_KEY = 'auroraaa-tab-cloak-v1';
const DEFAULT_SITE_TITLE = 'Auroraaa';

type TabIdentityId = 'classroom' | 'docs' | 'drive' | 'slides';
type TabCloakState = { identity: TabIdentityId; autoApply: boolean; enabled: boolean };
const tabIdentities: { id: TabIdentityId; title: string; domain: string; favicon: string }[] = [
  { id: 'classroom', title: 'Google Classroom', domain: 'classroom.google.com', favicon: 'https://ssl.gstatic.com/classroom/favicon.png' },
  { id: 'docs', title: 'Google Docs', domain: 'docs.google.com', favicon: 'https://www.gstatic.com/images/branding/productlogos/docs_2026/v2/web/192px.svg' },
  { id: 'drive', title: 'Google Drive', domain: 'drive.google.com', favicon: 'https://www.gstatic.com/images/branding/productlogos/drive_2026/v2/web/192px.svg' },
  { id: 'slides', title: 'Google Slides', domain: 'slides.google.com', favicon: 'https://www.gstatic.com/images/branding/productlogos/slides_2026/v2/web/192px.svg' },
];

function readWallpaper(): Wallpaper {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return { ...DEFAULT_WALLPAPER, ...JSON.parse(saved) };
  } catch { /* use the default when storage is unavailable */ }
  return DEFAULT_WALLPAPER;
}

function getWallpaperCss(w: Wallpaper) {
  if (w.kind === 'preset') return presets.find((p) => p.id === w.value)?.css ?? presets[0].css;
  if (w.kind === 'solid') return w.value;
  if (w.kind === 'gradient') return w.value;
  if (w.kind === 'url' || w.kind === 'upload') return `center / cover no-repeat url("${w.value.replaceAll('"', '%22')}")`;
  return presets[0].css;
}

function readTabCloakSettings(): TabCloakState {
  try {
    const saved = JSON.parse(localStorage.getItem(CLOAK_STORAGE_KEY) ?? '{}') as Partial<TabCloakState>;
    const identity = tabIdentities.find((option) => option.id === saved.identity)?.id ?? 'classroom';
    const autoApply = saved.autoApply === true;
    return { identity, autoApply, enabled: autoApply };
  } catch {
    return { identity: 'classroom', autoApply: false, enabled: false };
  }
}

function Logo() {
  return <Link href="/" className="brand-mark" aria-label="Auroraaa home">Auroraaa</Link>;
}

function TopBar({ path }: { path: string }) {
  return <header className="topbar">
    <Logo />
    <nav className="topnav" aria-label="Main navigation">
      {navigation.slice(1).map(({ href, label, icon: Icon }) => <Link key={href} href={href} aria-current={path === href ? 'page' : undefined} className={`nav-link ${path === href ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`}><Icon size={15} strokeWidth={1.8} /><span>{label}</span></Link>)}
      <Link href="/settings" aria-current={path === '/settings' ? 'page' : undefined} className={`nav-link settings-nav ${path === '/settings' ? 'active' : ''}`} data-testid="link-nav-settings"><Settings2 size={15} strokeWidth={1.8} /><span>Settings</span></Link>
    </nav>
  </header>;
}

function HomePage() {
  return <main className="home-page fade-in">
    <div className="home-center">
      <h1 className="home-title">AURORA</h1>
    </div>
  </main>;
}

function SettingsPage({ cloak, updateCloak }: {
  cloak: TabCloakState;
  updateCloak: (updates: Partial<TabCloakState>) => void;
}) {
  const [blankMessage, setBlankMessage] = useState('');
  const selectedIdentity = tabIdentities.find((identity) => identity.id === cloak.identity) ?? tabIdentities[0];

  const openAboutBlank = () => {
    setBlankMessage('');
    const blankWindow = window.open('about:blank', '_blank');
    if (!blankWindow) {
      setBlankMessage('Your browser blocked the new tab. Allow pop-ups for this site and try again.');
      return;
    }

    try {
      blankWindow.document.open();
      blankWindow.document.write('<!doctype html><html><head><meta charset="utf-8"><title>about:blank</title></head><body></body></html>');
      blankWindow.document.close();
      blankWindow.document.documentElement.style.cssText = 'height:100%;margin:0;';
      blankWindow.document.body.style.cssText = 'height:100%;margin:0;overflow:hidden;background:#0d1020;';
      const frame = blankWindow.document.createElement('iframe');
      frame.title = 'Auroraaa';
      frame.src = window.location.href;
      frame.style.cssText = 'display:block;width:100%;height:100%;border:0;';
      blankWindow.document.body.appendChild(frame);
      blankWindow.focus();
      setBlankMessage('Opened the launchpad in a separate about:blank tab.');
    } catch {
      blankWindow.close();
      setBlankMessage('The browser prevented opening the about:blank cloak.');
    }
  };

  return <main className="page-content settings-page fade-in">
    <div className="breadcrumb"><Link href="/">HOME</Link><span>/</span><span>SETTINGS</span></div>
    <div className="page-title-row settings-title-row">
      <div><div className="section-kicker">TAB APPEARANCE</div><h1 className="page-title">Settings<span className="title-period">.</span></h1></div>
      <div className="local-badge"><span /> SAVED ON THIS DEVICE</div>
    </div>

    <div className="cloak-settings">
      <section className="cloak-card" aria-labelledby="tab-cloak-heading">
        <div className="cloak-card-heading">
          <div className="cloak-card-icon"><ShieldCheck size={19} /></div>
          <div>
            <div className="section-kicker">CUSTOMIZE THE BROWSER TAB</div>
            <h2 id="tab-cloak-heading">Tab cloak</h2>
            <p>Choose a tab name and icon. This changes the browser tab only.</p>
          </div>
          <span className={`cloak-status ${cloak.enabled ? 'is-on' : ''}`}>{cloak.enabled ? 'ON' : 'OFF'}</span>
        </div>

        <div className="cloak-identity-grid" role="group" aria-label="Choose a tab identity">
          {tabIdentities.map((identity) => <button
            key={identity.id}
            type="button"
            className={`cloak-identity ${cloak.identity === identity.id ? 'selected' : ''}`}
            onClick={() => updateCloak({ identity: identity.id })}
            aria-pressed={cloak.identity === identity.id}
            data-testid={`button-cloak-${identity.id}`}
          >
            <img src={identity.favicon} alt="" />
            <span>{identity.title}</span>
            <small>{identity.domain}</small>
            {cloak.identity === identity.id && <Check size={14} className="cloak-identity-check" />}
          </button>)}
        </div>

        <label className="cloak-toggle-row">
          <span className="cloak-toggle-copy"><strong>Tab cloak</strong><small>Use {selectedIdentity.title} as this tab’s title and icon.</small></span>
          <input
            type="checkbox"
            role="switch"
            checked={cloak.enabled}
            onChange={(event) => updateCloak({ enabled: event.target.checked, ...(event.target.checked ? {} : { autoApply: false }) })}
            aria-label="Turn tab cloak on or off"
            data-testid="toggle-tab-cloak"
          />
        </label>
        <label className="cloak-toggle-row">
          <span className="cloak-toggle-copy"><strong>Auto-apply on launch</strong><small>Automatically use the selected identity each time Auroraaa opens.</small></span>
          <input
            type="checkbox"
            role="switch"
            checked={cloak.autoApply}
            onChange={(event) => updateCloak({ autoApply: event.target.checked, ...(event.target.checked ? { enabled: true } : {}) })}
            aria-label="Automatically apply tab cloak when Auroraaa opens"
            data-testid="toggle-auto-tab-cloak"
          />
        </label>
        {cloak.enabled && <button type="button" className="cloak-text-action" onClick={() => updateCloak({ enabled: false, autoApply: false })} data-testid="button-disable-tab-cloak"><EyeOff size={15} /> Turn off tab cloak</button>}
      </section>

      <section className="cloak-card about-blank-card" aria-labelledby="about-blank-heading">
        <div className="cloak-card-heading">
          <div className="cloak-card-icon"><ExternalLink size={18} /></div>
          <div>
            <div className="section-kicker">OPEN A DISCREET WINDOW</div>
            <h2 id="about-blank-heading">About:blank cloak</h2>
            <p>Open this launchpad in a new about:blank tab.</p>
          </div>
        </div>
        <button type="button" className="cloak-secondary-button" onClick={openAboutBlank} data-testid="button-about-blank-cloak">
          Open in about:blank <ExternalLink size={15} />
        </button>
        <p className="cloak-browser-note">Browsers require a click to open a new tab and may block embedded pages.</p>
        {blankMessage && <p className="cloak-feedback" role="status" aria-live="polite">{blankMessage}</p>}
      </section>
    </div>
  </main>;
}

function AppShell({ children, path, wallpaper }: { children: ReactNode; path: string; wallpaper: Wallpaper }) {
  const css = useMemo(() => getWallpaperCss(wallpaper), [wallpaper.kind, wallpaper.value]);
  return <div className={`app-shell ${path === '/' ? 'home-locked' : ''}`} style={{ '--wallpaper': css, '--dim': wallpaper.dim / 100 } as React.CSSProperties}>
    <div className="aurora-glow" aria-hidden="true" />
    <TopBar path={path} />
    {children}
  </div>;
}

function Router() {
  const [path] = useLocation();
  const wallpaper = readWallpaper();
  const [cloak, setCloak] = useState<TabCloakState>(readTabCloakSettings);
  const updateCloak = (updates: Partial<TabCloakState>) => setCloak((current) => ({ ...current, ...updates }));

  useEffect(() => {
    try {
      localStorage.setItem(CLOAK_STORAGE_KEY, JSON.stringify({ identity: cloak.identity, autoApply: cloak.autoApply }));
    } catch { /* keep the setting active for this session if storage is unavailable */ }
  }, [cloak.identity, cloak.autoApply]);

  useEffect(() => {
    const faviconLink = document.querySelector<HTMLLinkElement>('link[rel~="icon"]');
    const originalFavicon = faviconLink?.getAttribute('href') ?? '/favicon.svg';
    const originalFaviconType = faviconLink?.getAttribute('type');
    const identity = tabIdentities.find((option) => option.id === cloak.identity) ?? tabIdentities[0];

    if (cloak.enabled) {
      document.title = identity.title;
      faviconLink?.setAttribute('href', identity.favicon);
      faviconLink?.removeAttribute('type');
    } else {
      document.title = DEFAULT_SITE_TITLE;
      faviconLink?.setAttribute('href', originalFavicon);
      if (originalFaviconType) faviconLink?.setAttribute('type', originalFaviconType);
      else faviconLink?.removeAttribute('type');
    }

    return () => {
      document.title = DEFAULT_SITE_TITLE;
      faviconLink?.setAttribute('href', originalFavicon);
      if (originalFaviconType) faviconLink?.setAttribute('type', originalFaviconType);
      else faviconLink?.removeAttribute('type');
    };
  }, [cloak.enabled, cloak.identity]);

  const page = path === '/' ? <HomePage /> : path === '/aurora-ai' ? <AuroraAiPage /> : path === '/settings' ? <SettingsPage cloak={cloak} updateCloak={updateCloak} /> : blankRoutes.includes(path) ? <main className="blank-page" /> : null;
  if (!page) return <AppShell path={path} wallpaper={wallpaper}><Switch><Route component={NotFound} /></Switch></AppShell>;
  return <ErrorBoundary resetKey={path}><AppShell path={path} wallpaper={wallpaper}>{page}</AppShell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;