import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react";
import { useSendAuroraAiMessage } from "@workspace/api-client-react";
import { ArrowUp, Check, Copy, LoaderCircle, Plus, RotateCcw } from "lucide-react";

type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

const STORAGE_KEY = "auroraaa-ai-chat-v1";
const MAX_MESSAGE_LENGTH = 1600;

function readMessages(): ChatMessage[] {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as unknown;
    if (!Array.isArray(saved)) return [];
    return saved.filter((item): item is ChatMessage =>
      typeof item?.id === "string" &&
      (item.role === "user" || item.role === "assistant") &&
      typeof item.content === "string"
    );
  } catch {
    return [];
  }
}

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function getErrorMessage(error: unknown) {
  if (error && typeof error === "object" && "error" in error && typeof error.error === "string") {
    return error.error;
  }
  if (error && typeof error === "object" && "message" in error && typeof error.message === "string") {
    return error.message;
  }
  return "Your message didn’t make it through. Please try again.";
}

export default function AuroraAiPage() {
  const [messages, setMessages] = useState<ChatMessage[]>(readMessages);
  const [draft, setDraft] = useState("");
  const [copiedId, setCopiedId] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const retryPayloadRef = useRef<{ messages: { role: "user" | "assistant"; content: string }[] } | null>(null);
  const chat = useSendAuroraAiMessage();

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));
    } catch {
      // The conversation remains available for the current session if storage is blocked.
    }
  }, [messages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, chat.isPending]);

  useEffect(() => {
    if (!copiedId) return;
    const timer = window.setTimeout(() => setCopiedId(""), 1500);
    return () => window.clearTimeout(timer);
  }, [copiedId]);

  const submitPayload = async (payload: { messages: { role: "user" | "assistant"; content: string }[] }) => {
    retryPayloadRef.current = payload;
    try {
      const response = await chat.mutateAsync({
        data: {
          messages: payload.messages.slice(-12).map((message) => ({
            role: message.role,
            content: message.content.slice(0, MAX_MESSAGE_LENGTH),
          })),
        },
      });
      setMessages((current) => [...current, { id: createId(), role: "assistant", content: response.reply }]);
      retryPayloadRef.current = null;
    } catch {
      // Mutation error is rendered below; keep the exact request available for retry.
    }
  };

  const sendMessage = async (event?: FormEvent) => {
    event?.preventDefault();
    const content = draft.trim().slice(0, MAX_MESSAGE_LENGTH);
    if (!content || chat.isPending) return;

    const userMessage: ChatMessage = { id: createId(), role: "user", content };
    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    setDraft("");
    const payload = {
      messages: nextMessages.slice(-12).map(({ role, content: text }) => ({ role, content: text.slice(0, MAX_MESSAGE_LENGTH) })),
    };
    retryPayloadRef.current = payload;
    await submitPayload(payload);
  };

  const retry = () => {
    if (retryPayloadRef.current && !chat.isPending) void submitPayload(retryPayloadRef.current);
  };

  const startNewChat = () => {
    if (chat.isPending) return;
    setMessages([]);
    setDraft("");
    retryPayloadRef.current = null;
    chat.reset();
    textareaRef.current?.focus();
  };

  const handleComposerKeyDown = (event: KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void sendMessage();
    }
  };

  const copyMessage = async (message: ChatMessage) => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopiedId(message.id);
    } catch {
      setCopiedId("");
    }
  };

  return (
    <main className="aurora-chat-page">
      <section className="aurora-chat-frame" aria-label="Aurora AI conversation">
        <header className="aurora-chat-heading">
          <div className="aurora-chat-heading-copy">
            <h1>Aurora AI</h1>
            <p>Chat with an AI assistant.</p>
          </div>
          <button
            type="button"
            className="aurora-new-chat"
            onClick={startNewChat}
            disabled={chat.isPending || messages.length === 0}
            data-testid="button-new-chat"
            aria-label="Start a new chat"
          >
            <Plus size={15} /> New chat
          </button>
        </header>

        <div className={`aurora-conversation ${messages.length ? "has-messages" : "is-empty"}`} role="log" aria-live="polite" aria-relevant="additions text">
          {messages.length === 0 ? (
            <div className="aurora-welcome">
              <h2>How can I help?</h2>
              <p>Ask a question or talk through an idea.</p>
              <p className="aurora-private-note">History is saved in this browser. Messages are sent to Groq to generate replies.</p>
            </div>
          ) : (
            <div className="aurora-message-list">
              {messages.map((message) => (
                <article className={`aurora-message aurora-message-${message.role}`} key={message.id} data-testid={`message-${message.role}-${message.id}`}>
                  <div className="aurora-message-body">
                    {message.role === "assistant" && <div className="aurora-message-label">Aurora</div>}
                    <div className="aurora-message-bubble">{message.content}</div>
                    {message.role === "assistant" && (
                      <button type="button" className="aurora-copy-button" onClick={() => void copyMessage(message)} aria-label="Copy response" data-testid={`button-copy-${message.id}`}>
                        {copiedId === message.id ? <><Check size={12} /> Copied</> : <><Copy size={12} /> Copy</>}
                      </button>
                    )}
                  </div>
                </article>
              ))}
              {chat.isPending && (
                <div className="aurora-message aurora-message-assistant" role="status" data-testid="status-ai-pending">
                  <div className="aurora-message-body">
                    <div className="aurora-message-label">Aurora</div>
                    <div className="aurora-pending-bubble">Responding…</div>
                  </div>
                </div>
              )}
              {chat.isError && (
                <div className="aurora-error-note" role="alert" data-testid="status-ai-error">
                  <span>{getErrorMessage(chat.error)}</span>
                  <button type="button" onClick={retry} disabled={chat.isPending} data-testid="button-retry-message"><RotateCcw size={13} /> Retry</button>
                </div>
              )}
              <div ref={endRef} />
            </div>
          )}
        </div>

        <form className="aurora-composer-wrap" onSubmit={sendMessage}>
          {chat.isError && messages.length === 0 && (
            <div className="aurora-error-note aurora-error-empty" role="alert" data-testid="status-ai-error-empty">
              <span>{getErrorMessage(chat.error)}</span>
              <button type="button" onClick={retry} disabled={chat.isPending} data-testid="button-retry-message"><RotateCcw size={13} /> Retry</button>
            </div>
          )}
          <div className="aurora-composer">
            <textarea
              ref={textareaRef}
              value={draft}
              onChange={(event) => setDraft(event.target.value.slice(0, MAX_MESSAGE_LENGTH))}
              onKeyDown={handleComposerKeyDown}
              placeholder="Write a message…"
              rows={1}
              maxLength={MAX_MESSAGE_LENGTH}
              aria-label="Your message"
              data-testid="input-chat-message"
              disabled={chat.isPending}
            />
            <button
              type="submit"
              className="aurora-send-button"
              disabled={!draft.trim() || chat.isPending}
              aria-label={chat.isPending ? "Sending message" : "Send message"}
              data-testid="button-send-message"
            >
              {chat.isPending ? <LoaderCircle size={17} className="aurora-send-loading" /> : <ArrowUp size={18} />}
            </button>
          </div>
          <p className="aurora-composer-foot">History is saved on this device. Messages go to Groq for replies.</p>
        </form>
      </section>
    </main>
  );
}