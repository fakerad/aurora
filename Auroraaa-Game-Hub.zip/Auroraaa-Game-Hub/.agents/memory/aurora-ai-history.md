---
name: Aurora AI chat history
description: Persistence and privacy boundary for Aurora AI conversations.
---

Keep Aurora AI history in browser localStorage; do not add server-side transcript storage by default. The API receives recent turns only to generate replies.

**Why:** Chat may contain personal reflections. There is no account-sync requirement or retention policy, so local storage avoids persisting transcripts server-side while providing same-device continuity.

**How to apply:** Keep history and provider-processing disclosures explicit. If cross-device history is requested, confirm retention, deletion, and consent before adding a database.