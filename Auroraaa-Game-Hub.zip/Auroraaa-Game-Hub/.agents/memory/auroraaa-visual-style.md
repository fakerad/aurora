---
name: Auroraaa visual style
description: User-requested visual direction for shared Auroraaa pages.
---

Keep Auroraaa simple and functional while preserving its aurora background and the icons beside page names. Use open page layouts and restrained controls; avoid framed panels that can read as popups.

**Why:** The user asked for Aurora AI to open as a page rather than look like a popup, asked for a simpler site, and clarified that the aurora background and page icons should remain.

**How to apply:** Keep the background treatment and navigation icons, but keep page content uncluttered unless the user asks for a more decorative layout.